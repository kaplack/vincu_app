// This project is intended to be used with React + JavaScript.
// Types were removed during the TS -> JS conversion.
// Keep this file if you want a single place to centralize shared constants.
