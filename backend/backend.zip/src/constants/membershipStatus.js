const MEMBERSHIP_STATUS = Object.freeze({
  INVITED: "INVITED",
  ACTIVE: "ACTIVE",
  SUSPENDED: "SUSPENDED",
});

module.exports = { MEMBERSHIP_STATUS };
