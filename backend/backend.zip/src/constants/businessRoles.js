const BUSINESS_ROLES = Object.freeze({
  OWNER: "OWNER",
  MANAGER: "MANAGER",
  OPERATOR: "OPERATOR",
});

module.exports = { BUSINESS_ROLES };
