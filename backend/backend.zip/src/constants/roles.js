const ROLES = Object.freeze({
  SUPERADMIN: "SUPERADMIN",
  USER: "USER",
});

module.exports = { ROLES };
